class Config:
    SECRET_KEY = 'your-very-secret-key'
    SQLALCHEMY_DATABASE_URI = 'postgresql://olificecuser:StrongPasswordHere@localhost/olificecdb'
    SQLALCHEMY_TRACK_MODIFICATIONS = False