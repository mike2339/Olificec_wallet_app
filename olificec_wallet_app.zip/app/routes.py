from flask import Blueprint, render_template, request, redirect, url_for, session, flash
from flask_login import login_user, logout_user, login_required
from werkzeug.security import check_password_hash
from .models import Admin, User, GiftCard
from . import db, login_manager
import random, string

main = Blueprint('main', __name__)

@login_manager.user_loader
def load_user(admin_id):
    return Admin.query.get(int(admin_id))

@main.route('/')
def index():
    return redirect(url_for('main.homepage'))

@main.route('/home')
def homepage():
    return render_template('index.html')

@main.route('/admin/login', methods=['GET', 'POST'])
def admin_login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        admin = Admin.query.filter_by(username=username).first()
        if admin and check_password_hash(admin.password_hash, password):
            login_user(admin)
            return redirect(url_for('main.admin_dashboard'))
        return "Invalid credentials", 401

    return render_template('login.html')

@main.route('/admin/dashboard')
@login_required
def admin_dashboard():
    return render_template('dashboard.html')

@main.route('/admin/logout')
@login_required
def admin_logout():
    logout_user()
    return redirect(url_for('main.admin_login'))

@main.route('/admin/giftcards/create', methods=['POST'])
@login_required
def create_giftcard():
    amount = int(request.form['amount'])
    code = ''.join(random.choices(string.ascii_uppercase + string.digits, k=12))

    gift = GiftCard(code=code, amount=amount)
    db.session.add(gift)
    db.session.commit()
    flash(f"Gift card {code} created successfully.")
    return redirect(url_for('main.admin_dashboard'))

@main.route('/admin/wallet/add', methods=['POST'])
@login_required
def add_wallet_funds():
    user_id = int(request.form['user_id'])
    amount = int(request.form['amount'])

    user = User.query.get(user_id)
    if user:
        user.wallet_balance += amount
        db.session.commit()
        flash(f"Added ₦{amount / 100:.2f} to user {user.email}")
    else:
        flash("User not found.")
    return redirect(url_for('main.admin_dashboard'))

@main.route('/redeem', methods=['POST'])
def redeem_giftcard():
    email = request.form['email']
    code = request.form['code'].strip().upper()

    user = User.query.filter_by(email=email).first()
    if not user:
        user = User(email=email, wallet_balance=0)
        db.session.add(user)
        db.session.commit()

    gift = GiftCard.query.filter_by(code=code, is_redeemed=False).first()
    if not gift:
        return "Invalid or already redeemed code.", 400

    user.wallet_balance += gift.amount
    gift.is_redeemed = True
    gift.redeemed_by = user.id

    db.session.commit()
    return f"Success! ₦{gift.amount / 100:.2f} has been added to {email}'s wallet."